module.exports = {
    InfoController: require('./info-controller'),
    UserController: require('./user-controller'),
    LocationController: require('./location-controller'),
    TripBookingController: require('./Trip-booking-controller'),
} 